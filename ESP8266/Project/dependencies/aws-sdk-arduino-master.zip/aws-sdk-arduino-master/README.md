forked from svdgraaf/aws-sdk-arduino
I've restructed the files to use it for esp8266 and make the use of https://github.com/odelot/aws-mqtt-websockets library easier.

https://github.com/odelot/aws-mqtt-websockets depends of sha256 and Utils

if you want to know more about this library, visit https://github.com/svdgraaf/aws-sdk-arduino
